/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   window.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgourley <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/07/27 11:52:23 by wgourley          #+#    #+#             */
/*   Updated: 2018/08/17 13:49:08 by wgourley         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <sdlgf.h>

static t_window	*create_window(void)
{
	t_window *ret;

	ret = (t_window *)ft_memalloc(sizeof(t_window));
	ret->context = mlx_init();
	if (!ret->context)
		init_error("Could not init libriary");
	ft_putendl("Context created");
	ret->window_pointer = mlx_new_window(ret->context,
					WINDOW_W, WINDOW_H, WINDOW_TITLE);
	if (!ret->window_pointer)
		init_error("Could not create window");
	ft_putendl("Window inited");
	ret->image = NULL;
	return (ret);
}

t_window		*get_window(void)
{
	static t_window	*ret = NULL;

	if (ret)
		return (ret);
	ret = create_window();
	return (ret);
}

void			close_window(void)
{
	mlx_destroy_window(get_window()->context, get_window()->window_pointer);
	free(get_window());
	exit(1);
}
