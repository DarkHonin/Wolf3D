/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   window.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgourley <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/07/27 11:52:23 by wgourley          #+#    #+#             */
/*   Updated: 2018/08/17 13:49:08 by wgourley         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <sdlgf.h>

static void		create_window(t_window *ret)
{
	int				init;

	init = SDL_Init(SDL_INIT_VIDEO);
	ret->context = &init;
	if (!ret->context)
		init_error("Could not init libriary");
	ret->window_pointer = SDL_CreateWindow("FDF", 100, 100, WINDOW_W, WINDOW_H, SDL_WINDOW_INPUT_FOCUS);
	if (!ret->window_pointer)
		init_error("Could not create window");

}

t_window	*get_window()
{
	static t_window	*ret = NULL;

	if (ret)
		return (ret);
	ret = create_window();
	return (ret);
}

void		close_window()
{
	#ifdef SLD_h_
		SDL_DestroyWindow(get_window()->window_pointer);
	#elif defined MLX_H
		mlx_destroy_window(get_window()->context, get_window()->window_pointer);
	#endif
	free(get_window());
	exit(1);
}