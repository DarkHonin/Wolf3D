/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   image.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgourley <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/07/28 13:19:55 by wgourley          #+#    #+#             */
/*   Updated: 2018/08/17 13:49:08 by wgourley         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <sdlgf.h>


/*
** The image type is dependent on the librairy being use.
** In the case of SDL it will return a SDL_Renderer and 
** in the case of mlx it will return a MLX_Image pointer
** the pointer it self is static and will be held onto 
** untill the program closes
*/

void	*get_image()
{
	t_window *win;
	void	*image;

	win = get_window();
	image = win->image;
	if (image)
		return (image);
		image = SDL_CreateRenderer(win->window_pointer, 0, SDL_WINDOW_INPUT_FOCUS);
	
	return (image);
}

void	flip()
{
	SDL_RenderPresent(get_image());
}

void clean()
{
	void *image;

	image = get_image();
	if (!image)
		return ;
	SDL_SetRenderDrawColor(image, 0, 0, 0, 0);
	SDL_RenderClear(image);
}