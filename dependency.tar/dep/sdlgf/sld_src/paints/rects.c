/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rects.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgourley <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/06 12:54:52 by wgourley          #+#    #+#             */
/*   Updated: 2018/08/17 13:49:08 by wgourley         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <sdlgf.h>

void	draw_rect(t_value_v a, t_value_v b, t_len l, t_color c)
{
	t_len				x;
	t_len				y;
	t_value_v			size;
	t_size				o;


	size = clone_value_v(a, l);
	o[0] = l;
	o[1] = 1;
	sync_function_m(&size, &b, &v_subtraction, o);
	y = 0;
	while (y < ABS(size[1]))
	{
		x = 0;
		while (x < ABS(size[0]))
		{
			put_pixel(a[0] + x, a[1] + y, c[0], c[1], c[2]);
			x++;
		}
		y++;
	}
	free(size);
}

