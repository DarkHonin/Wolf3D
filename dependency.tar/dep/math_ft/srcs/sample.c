/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sample.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgourley <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/08 00:33:48 by wgourley          #+#    #+#             */
/*   Updated: 2018/08/17 13:30:26 by wgourley         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <math_ft.h>

t_value_v	get_column(t_value_m a, t_size dim, t_len col)
{
	t_len		e;
	t_value_v	q;

	e = 0;
	q = create_value_v(dim[1]);
	while (e < dim[1])
	{
		q[e] = a[e][col];
		e++;
	}
	return (q);
}
