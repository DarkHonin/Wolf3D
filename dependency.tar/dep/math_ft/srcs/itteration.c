/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   itteration.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgourley <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/07 21:17:25 by wgourley          #+#    #+#             */
/*   Updated: 2018/08/17 13:37:11 by wgourley         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <math_ft.h>

void	apply_function(t_value_v vec, t_value (*f)(t_value, t_len), t_len len)
{
	t_len t;

	t = 0;
	while (t < len)
	{
		vec[t] = f(vec[t], t);
		t++;
	}
}

void	sync_function(t_value_v vec, t_value_v vec2,
	t_value (*f)(t_value, t_value, t_len), t_len len)
{
	t_len t;

	t = 0;
	while (t < len)
	{
		vec[t] = f(vec[t], vec2[t], t);
		t++;
	}
}

void	apply_function_m(t_value_m vec,
	t_value (*f)(t_value, t_size), t_size size)
{
	t_size index;

	index[1] = 0;
	while (index[1] < size[1])
	{
		index[0] = 0;
		while (index[0] < size[0])
		{
			vec[index[1]][index[0]] = f(vec[index[1]][index[0]], index);
			index[0]++;
		}
		index[1]++;
	}
}

void	sync_function_m(t_value_m vec, t_value_m vec2,
	t_value (*f)(t_value, t_value, t_size), t_size size)
{
	t_size index;

	index[1] = 0;
	while (index[1] < size[1])
	{
		index[0] = 0;
		while (index[0] < size[0])
		{
			vec[index[1]][index[0]] = f(vec[index[1]][index[0]],
				vec2[index[1]][index[0]], index);
			index[0]++;
		}
		index[1]++;
	}
}

void	apply_value(t_value_v e, t_value v, t_len l,
	t_value (*f)(t_value, t_value))
{
	t_len c;

	c = 0;
	while (c < l)
	{
		e[c] = f(e[c], v);
		c++;
	}
}
