/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   restructure.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgourley <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/12 13:49:59 by wgourley          #+#    #+#             */
/*   Updated: 2018/08/13 14:31:43 by wgourley         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <math_ft.h>

void	append_to_value_v(t_value_v *e, t_len l, t_value v)
{
	t_value_v	ret;
	t_len		i;

	ret = create_value_v(l + 1);
	i = 0;
	while (i < l)
	{
		ret[i] = (*e)[i];
		i++;
	}
	ret[l] = v;
	free(*e);
	*e = ret;
}
