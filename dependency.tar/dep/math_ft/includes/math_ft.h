/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   math_ft.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgourley <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/07 17:37:08 by wgourley          #+#    #+#             */
/*   Updated: 2018/08/17 13:54:08 by wgourley         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MATH_FT_H
# define MATH_FT_H

# include <libft.h>

typedef	float				t_value;
typedef	t_value				*t_value_v;
typedef t_value_v			*t_value_m;

typedef unsigned long int	t_len;

typedef t_len				t_size[2];

t_value_m					create_value_m(t_size e);
t_value_v					create_value_v(t_len len);
void						free_value_m(t_value_m q, t_len height);
void						apply_function(t_value_v vec,
						t_value (*f)(t_value, t_len), t_len len);
void						apply_function_m(t_value_m vec,
						t_value (*f)(t_value, t_size), t_size size);
void						sync_function(t_value_v vec, t_value_v vec2,
						t_value (*f)(t_value, t_value, t_len), t_len len);
void						sync_function_m(t_value_m vec, t_value_m vec2,
						t_value (*f)(t_value, t_value, t_size), t_size len);
t_value_v					get_column(t_value_m a, t_size dim, t_len col);
void						t_value_matrix_multiple(t_value_m a,
						t_value_m b, t_size c, t_size d);
t_value						distance(t_value_v point, t_len len);
t_value_v					clone_value_v(t_value_v v, t_len l);
void						append_to_value_v(t_value_v *e, t_len l, t_value v);
t_value						v_division(t_value a, t_value b, t_size e);
t_value						v_multiple(t_value a, t_value b, t_size e);
t_value						v_subtraction(t_value a, t_value b, t_size e);
t_value						v_addition(t_value a, t_value b, t_size e);
void						log_value_v(t_value_v q, t_len l);
void						apply_value(t_value_v e, t_value v,
						t_len l, t_value (*f)(t_value, t_value));
#endif
