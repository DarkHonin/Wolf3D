/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   draw.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgourley <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/07/28 13:18:12 by wgourley          #+#    #+#             */
/*   Updated: 2018/08/17 13:49:08 by wgourley         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <sdlgf.h>

static unsigned int	get_pixel_color(int r, int g, int b)
{
	unsigned int	ret;
	unsigned char	*bytes;

	ret = 0x00FFFFFF;
	bytes = (unsigned char *)&ret;
	bytes[1] = (char)g;
	bytes[0] = (char)b;
	bytes[2] = (char)r;
	return (ret);
}

static void			render_px(int x, int y, t_color c)
{
	char			*image;
	t_window		*win;
	int				offset;
	unsigned int	color;

	if (!IN_VIEW(x, y))
		return ;
	get_image();
	win = get_window();
	image = win->image_addr;
	offset = (x * (win->bites_per_pixel / 8)) + (win->line_len * y);
	color = get_pixel_color(c[0], c[1], c[2]);
	*((int *)(image + offset)) = color;
}

void				put_pixel(int x, int y, t_color c)
{
	render_px(x, y, c);
}
