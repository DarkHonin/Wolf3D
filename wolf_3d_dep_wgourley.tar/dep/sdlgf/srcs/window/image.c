/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   image.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgourley <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/07/28 13:19:55 by wgourley          #+#    #+#             */
/*   Updated: 2018/08/17 13:49:08 by wgourley         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <sdlgf.h>

void	*get_image(void)
{
	t_window	*win;
	void		*image;

	win = get_window();
	image = win->image;
	if (image)
		return (image);
	image = mlx_new_image(win->context, WINDOW_W, WINDOW_H);
	win->image = image;
	win->image_addr = mlx_get_data_addr(image,
			&win->bites_per_pixel, &win->line_len, &win->ed);
	ft_putendl("Image created ");
	ft_putstr("Bits per pixel: ");
	ft_putnbr(win->bites_per_pixel);
	ft_putendl("");
	return (image);
}

void	flip(void)
{
	mlx_clear_window(get_window()->context, get_window()->window_pointer);
	mlx_put_image_to_window(get_window()->context,
		get_window()->window_pointer, get_image(), 0, 0);
}

void	clean(void)
{
	void *image;

	image = get_image();
	if (!image)
		return ;
	mlx_destroy_image(get_window()->context, image);
	get_window()->image = NULL;
	get_image();
}
