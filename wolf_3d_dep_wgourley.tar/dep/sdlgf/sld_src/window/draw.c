/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   draw.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgourley <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/07/28 13:18:12 by wgourley          #+#    #+#             */
/*   Updated: 2018/08/17 14:26:45 by wgourley         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <sdlgf.h>
static unsigned int	get_pixel_color(int r, int g, int b)
{
	unsigned int ret;
	unsigned char	*bytes;
	
	ret = 0x00FFFFFF;
	bytes = (unsigned char *)&ret;
	bytes[1] = (char)g;
	bytes[0] = (char)b;
	bytes[2] = (char)r;
	return (ret);
}

static void render_px(int x, int y, int r, int g, int b)
{
	void *image;

	
	if (!IN_VIEW(x, y))
		return ;
	image = get_image();
	SDL_SetRenderDrawColor(image, r, g, b, SDL_ALPHA_OPAQUE);
	SDL_RenderDrawPoint(image, x, y);
}

void	put_pixel(int x, int y, int r, int g, int b)
{
	render_px(x, y, r, g, b);
}