/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   lines.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgourley <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/07 11:18:09 by wgourley          #+#    #+#             */
/*   Updated: 2018/08/17 13:49:08 by wgourley         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <sdlgf.h>

void	draw_line(t_value_v a, t_value_v b, t_len s, t_color c)
{
	float		x;
	float		delta;
	t_value_v	size;
	t_size		ss;

	size = clone_value_v(a, s);
	ss[0] = s;
	ss[1] = 1;
	sync_function_m(&size, &b, &v_subtraction, ss);
	delta = distance(size, s);
	x = 0;
	while (x < delta)
	{
		put_pixel(((x / delta) * size[0]) + b[0], ((x / delta) * size[1]) + b[1], c[0], c[1], c[2]);
		x++;
	}
	free(size);
}