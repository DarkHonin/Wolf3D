/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sdlgf.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgourley <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/07/28 00:21:03 by wgourley          #+#    #+#             */
/*   Updated: 2018/08/17 13:49:08 by wgourley         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SDLGF_H
# define SDLGF_H

# ifndef WINDOW_W
#  define WINDOW_W 800
# endif

# ifndef WINDOW_H
#  define WINDOW_H 600
# endif

# ifndef WINDOW_TITLE
#  define WINDOW_TITLE "NEW_WINDOW"
# endif

# define WINDOW_C_W WINDOW_W/2
# define WINDOW_C_H WINDOW_H/2

# define IN_VIEW(x, y) (x > 0 && x < WINDOW_W) && (y > 0 && y < WINDOW_H)

# include <libft.h>
# include <math_ft.h>
# include <mlx.h>

typedef struct	s_window
{
	void	*window_pointer;
	void	*context;
	int		bites_per_pixel;
	int		line_len;
	int		ed;
	void	*image_addr;
	void	*image;
}				t_window;

typedef	int	t_color[3];

void			init_error(char *msg);
void			file_error(char *msg);
t_window		*get_window();
void			*get_image();
void			put_pixel(int x, int y, t_color c);
void			flip();
void			clean();
void			start_loop();
void			draw_rect(t_value_v a, t_value_v b, t_len l, t_color c);
void			draw_line(t_value_v a, t_value_v b, t_len s, t_color c);
void			close_window();
#endif
