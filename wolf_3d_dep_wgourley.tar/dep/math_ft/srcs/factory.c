/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   factory.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgourley <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/07 17:47:18 by wgourley          #+#    #+#             */
/*   Updated: 2018/08/17 13:39:54 by wgourley         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <math_ft.h>

t_value_v	create_value_v(t_len len)
{
	t_value_v	ret;

	ret = (t_value_v)ft_memalloc(sizeof(t_value) * len);
	return (ret);
}

t_value_m	create_value_m(t_size e)
{
	t_value_m	ret;
	t_len		index;

	ret = (t_value_m)ft_memalloc(sizeof(t_value_v) * e[1]);
	index = 0;
	while (index < e[1])
		ret[index++] = create_value_v(e[0]);
	return (ret);
}

void		free_value_m(t_value_m q, t_len height)
{
	t_len	y;

	y = 0;
	while (y < height)
		free(q[y++]);
	free(q);
}
