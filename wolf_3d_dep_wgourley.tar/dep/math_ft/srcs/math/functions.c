/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   functions.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgourley <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/08 00:26:25 by wgourley          #+#    #+#             */
/*   Updated: 2018/08/17 13:38:09 by wgourley         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <math_ft.h>

t_value	v_addition(t_value a, t_value b, t_size e)
{
	return (a + b + (e[0] * 0));
}

t_value	v_subtraction(t_value a, t_value b, t_size e)
{
	return (a - b + (e[0] * 0));
}

t_value	v_multiple(t_value a, t_value b, t_size e)
{
	return (a * b + (e[0] * 0));
}

t_value	v_division(t_value a, t_value b, t_size e)
{
	return (a / (b + (b == 0)) + (e[0] * 0));
}
