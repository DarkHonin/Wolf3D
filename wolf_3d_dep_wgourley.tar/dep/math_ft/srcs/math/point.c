/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   point.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgourley <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/12 12:54:22 by wgourley          #+#    #+#             */
/*   Updated: 2018/08/17 13:32:13 by wgourley         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <math_ft.h>
#include <math.h>

t_value		distance(t_value_v point, t_len len)
{
	t_len	index;
	t_value t;

	index = 0;
	t = 0;
	while (index < len)
	{
		t += pow(point[index], 2);
		index++;
	}
	return (sqrt(t));
}

t_value_v	clone_value_v(t_value_v v, t_len l)
{
	t_value_v	ret;
	t_len		i;

	ret = create_value_v(l);
	i = 0;
	while (i < l)
	{
		ret[i] = v[i];
		i++;
	}
	return (ret);
}
