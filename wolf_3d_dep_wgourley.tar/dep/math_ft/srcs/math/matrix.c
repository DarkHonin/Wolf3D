/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   matrix.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wgourley <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/08 00:29:16 by wgourley          #+#    #+#             */
/*   Updated: 2018/08/17 14:26:47 by wgourley         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <math_ft.h>

void	t_value_matrix_multiple(t_value_m a, t_value_m b, t_size c, t_size d)
{
	t_size	i;
	t_len	crow;
	t_value	holder;

	if (c[0] != d[1])
	{
		ft_putendl("Matrix dimentions not valid");
		return ;
	}
	i[1] = 0;
	while (i[1] < c[1])
	{
		i[0] = 0;
		while (i[0] < c[0])
		{
			crow = 0;
			holder = 0;
			while (crow < c[0])
				holder += a[i[1]][i[0]] * b[crow++][i[0]];
			a[i[1]][i[0]] = holder;
			i[0]++;
		}
		i[1]++;
	}
}
